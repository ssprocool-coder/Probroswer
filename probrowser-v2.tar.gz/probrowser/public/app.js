/* Pro Browser — Core JS */
'use strict';

// ── Constants ──────────────────────────────────────────────────────────────
const KEYS = {
  THEME: 'pb-theme',
  BROWSER_HIST: 'pb-browser-history',
  SEARCH_HIST: 'pb-search-history',
  SHORTCUTS: 'pb-shortcuts',
  SETTINGS: 'pb-settings',
  BOOKMARKS: 'pb-bookmarks',
  DOWNLOADS: 'pb-downloads',
  MODE: 'pb-mode',
};
const HIST_EXPIRE_MS = 10 * 30 * 24 * 60 * 60 * 1000; // 10 months

// ── Settings ───────────────────────────────────────────────────────────────
function getSettings() {
  try { return JSON.parse(localStorage.getItem(KEYS.SETTINGS) || '{}'); } catch { return {}; }
}
function saveSetting(key, val) {
  const s = getSettings(); s[key] = val;
  localStorage.setItem(KEYS.SETTINGS, JSON.stringify(s));
}
window.getSettings = getSettings;
window.saveSetting = saveSetting;

// ── Theme ──────────────────────────────────────────────────────────────────
function getTheme() { return localStorage.getItem(KEYS.THEME) || 'light'; }
function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  const btn = document.getElementById('themeToggle');
  if (btn) btn.textContent = t === 'dark' ? '☀️' : '🌙';
}
function toggleTheme() {
  const next = getTheme() === 'dark' ? 'light' : 'dark';
  localStorage.setItem(KEYS.THEME, next);
  applyTheme(next);
}
applyTheme(getTheme());
document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('themeToggle');
  if (btn) btn.onclick = toggleTheme;
});

// ── Toast ──────────────────────────────────────────────────────────────────
function showToast(msg) {
  let c = document.querySelector('.toast-container');
  if (!c) { c = document.createElement('div'); c.className = 'toast-container'; document.body.appendChild(c); }
  const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg;
  c.appendChild(t); setTimeout(() => t.remove(), 2900);
}
window.showToast = showToast;

// ── Context Menu ───────────────────────────────────────────────────────────
function openCtxMenu(items, e) {
  closeCtxMenu();
  const menu = document.createElement('div'); menu.className = 'ctx-menu'; menu.id = '_ctxMenu';
  for (const item of items) {
    if (item === 'sep') {
      const sep = document.createElement('div'); sep.className = 'ctx-menu__sep'; menu.appendChild(sep); continue;
    }
    const el = document.createElement('div');
    el.className = 'ctx-menu__item' + (item.danger ? ' danger' : '');
    el.innerHTML = `<span class="ctx-icon">${item.icon||''}</span><span>${item.label}</span>`;
    el.onclick = () => { closeCtxMenu(); item.action(); };
    menu.appendChild(el);
  }
  document.body.appendChild(menu);
  let x = e.clientX, y = e.clientY;
  const mW = 220;
  if (x + mW > window.innerWidth) x = window.innerWidth - mW - 8;
  if (y + menu.offsetHeight > window.innerHeight) y = y - menu.offsetHeight;
  menu.style.cssText = `left:${x}px;top:${y}px`;
  setTimeout(() => document.addEventListener('click', closeCtxMenu, { once: true }), 10);
}
function closeCtxMenu() { document.getElementById('_ctxMenu')?.remove(); }
window.openCtxMenu = openCtxMenu;

// ── Escape HTML ────────────────────────────────────────────────────────────
function escHtml(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
window.escHtml = escHtml;

// ── Format time ────────────────────────────────────────────────────────────
function formatTime(ts) {
  const diff = Date.now() - ts;
  if (diff < 60000) return 'just now';
  if (diff < 3600000) return Math.floor(diff/60000)+'m ago';
  if (diff < 86400000) return Math.floor(diff/3600000)+'h ago';
  return Math.floor(diff/86400000)+'d ago';
}
window.formatTime = formatTime;

// ── Browser History ────────────────────────────────────────────────────────
function getBrowserHistory() {
  try { return JSON.parse(localStorage.getItem(KEYS.BROWSER_HIST) || '[]'); } catch { return []; }
}
function addBrowserHistory(title, url) {
  const s = getSettings();
  if (s.saveBrowseHist === false || getCurrentMode() === 'private') return;
  let hist = getBrowserHistory().filter(h => h.url !== url);
  hist.unshift({ title, url, time: Date.now() });
  // expire old items
  hist = hist.filter(h => (Date.now() - h.time) < HIST_EXPIRE_MS);
  localStorage.setItem(KEYS.BROWSER_HIST, JSON.stringify(hist.slice(0, 200)));
}
function clearBrowserHistory() { localStorage.removeItem(KEYS.BROWSER_HIST); }
window.getBrowserHistory = getBrowserHistory;
window.addBrowserHistory = addBrowserHistory;
window.clearBrowserHistory = clearBrowserHistory;

// ── Search History ─────────────────────────────────────────────────────────
function getSearchHistory() {
  try {
    let items = JSON.parse(localStorage.getItem(KEYS.SEARCH_HIST) || '[]');
    // Expire old, update structure
    const now = Date.now();
    items = items.filter(it => {
      if (typeof it === 'string') return true; // legacy
      return (now - it.lastUsed) < HIST_EXPIRE_MS;
    }).map(it => typeof it === 'string' ? { q: it, lastUsed: now } : it);
    return items;
  } catch { return []; }
}
function addSearchHistory(query) {
  const s = getSettings();
  if (s.saveSearchHist === false || getCurrentMode() === 'private') return;
  let items = getSearchHistory().filter(it => it.q !== query);
  items.unshift({ q: query, lastUsed: Date.now() });
  localStorage.setItem(KEYS.SEARCH_HIST, JSON.stringify(items.slice(0, 100)));
}
function touchSearchHistory(query) {
  let items = getSearchHistory();
  const idx = items.findIndex(it => it.q === query);
  if (idx >= 0) { items[idx].lastUsed = Date.now(); localStorage.setItem(KEYS.SEARCH_HIST, JSON.stringify(items)); }
}
function removeSearchHistItem(query) {
  const items = getSearchHistory().filter(it => it.q !== query);
  localStorage.setItem(KEYS.SEARCH_HIST, JSON.stringify(items));
}
function clearSearchHistory() { localStorage.removeItem(KEYS.SEARCH_HIST); }
window.getSearchHistory = getSearchHistory;
window.addSearchHistory = addSearchHistory;
window.clearSearchHistory = clearSearchHistory;
window.removeSearchHistItem = removeSearchHistItem;

// ── Shortcuts ──────────────────────────────────────────────────────────────
function getShortcuts() { try { return JSON.parse(localStorage.getItem(KEYS.SHORTCUTS) || '[]'); } catch { return []; } }
function saveShortcuts(sc) { localStorage.setItem(KEYS.SHORTCUTS, JSON.stringify(sc)); }
window.getShortcuts = getShortcuts;
window.saveShortcuts = saveShortcuts;

// ── Bookmarks ──────────────────────────────────────────────────────────────
function getBookmarks() { try { return JSON.parse(localStorage.getItem(KEYS.BOOKMARKS) || '[]'); } catch { return []; } }
function saveBookmarks(bm) { localStorage.setItem(KEYS.BOOKMARKS, JSON.stringify(bm)); }
function addBookmark(url, title) {
  const bm = getBookmarks();
  if (bm.some(b => b.url === url)) { showToast('Already bookmarked'); return false; }
  bm.unshift({ id: Date.now().toString(), url, title: title||url, time: Date.now() });
  saveBookmarks(bm); showToast('Bookmarked!'); return true;
}
function removeBookmark(url) {
  saveBookmarks(getBookmarks().filter(b => b.url !== url));
}
function isBookmarked(url) { return getBookmarks().some(b => b.url === url); }
window.getBookmarks = getBookmarks;
window.saveBookmarks = saveBookmarks;
window.addBookmark = addBookmark;
window.removeBookmark = removeBookmark;
window.isBookmarked = isBookmarked;

// ── Downloads ──────────────────────────────────────────────────────────────
function getDownloads() { try { return JSON.parse(localStorage.getItem(KEYS.DOWNLOADS) || '[]'); } catch { return []; } }
function saveDownloads(dl) { localStorage.setItem(KEYS.DOWNLOADS, JSON.stringify(dl)); }
function addDownload(url, name, size) {
  const dl = getDownloads();
  dl.unshift({ id: Date.now().toString(), url, name: name||url, size: size||'', time: Date.now() });
  saveDownloads(dl.slice(0, 100));
}
window.getDownloads = getDownloads;
window.saveDownloads = saveDownloads;
window.addDownload = addDownload;

// ── Browser Mode ───────────────────────────────────────────────────────────
function getCurrentMode() { return localStorage.getItem(KEYS.MODE) || 'normal'; }
function setCurrentMode(m) { localStorage.setItem(KEYS.MODE, m); }
window.getCurrentMode = getCurrentMode;
window.setCurrentMode = setCurrentMode;

// ── Favicon ────────────────────────────────────────────────────────────────
function faviconUrl(url) {
  try { return `https://${new URL(url).hostname}/favicon.ico`; } catch { return ''; }
}
window.faviconUrl = faviconUrl;

// ── Navigate to browser ────────────────────────────────────────────────────
function openInBrowser(url, title) {
  addBrowserHistory(title||url, url);
  const p = new URLSearchParams({ url, title: title||'' });
  window.location.href = `/browser?${p}`;
}
window.openInBrowser = openInBrowser;

// ── Suggestions ────────────────────────────────────────────────────────────
function attachSuggestions(inputEl, dropdownEl, onSelect) {
  let debounce;

  function showSuggestions() {
    const q = inputEl.value.trim();
    if (!q) {
      // Show recent searches when focused with empty input
      const recent = getSearchHistory().slice(0, 6);
      if (!recent.length) { dropdownEl.classList.add('hidden'); return; }
      dropdownEl.innerHTML = '<div class="suggest-section-label">Recent</div>';
      for (const it of recent) {
        const qStr = typeof it === 'string' ? it : it.q;
        const item = document.createElement('div'); item.className = 'suggestion-item';
        item.innerHTML = `
          <span class="suggestion-item__icon">🕐</span>
          <span class="suggestion-item__text">${escHtml(qStr)}</span>
          <button class="suggestion-item__del" title="Remove">✕</button>`;
        item.querySelector('.suggestion-item__del').onclick = (e) => {
          e.stopPropagation(); removeSearchHistItem(qStr); showSuggestions();
        };
        item.onclick = (e) => { if (e.target.tagName === 'BUTTON') return; inputEl.value = qStr; dropdownEl.classList.add('hidden'); onSelect(qStr); };
        dropdownEl.appendChild(item);
      }
      dropdownEl.classList.remove('hidden');
      return;
    }

    clearTimeout(debounce);
    debounce = setTimeout(async () => {
      const histMatches = getSearchHistory()
        .filter(it => { const s = typeof it==='string'?it:it.q; return s.toLowerCase().startsWith(q.toLowerCase()); })
        .slice(0, 3)
        .map(it => typeof it==='string'?it:it.q);

      let apiSuggestions = [];
      try {
        const r = await fetch(`/api/suggest?q=${encodeURIComponent(q)}`);
        const d = await r.json();
        apiSuggestions = (d.suggestions || []).slice(0, 5);
      } catch {}

      const all = [...new Set([...histMatches, ...apiSuggestions])].slice(0, 8);
      if (!all.length) { dropdownEl.classList.add('hidden'); return; }

      dropdownEl.innerHTML = '';
      if (histMatches.length) dropdownEl.innerHTML += '<div class="suggest-section-label">Recent</div>';
      for (const s of all) {
        const isHist = histMatches.includes(s);
        const item = document.createElement('div'); item.className = 'suggestion-item';
        item.innerHTML = `
          <span class="suggestion-item__icon">${isHist ? '🕐' : '🔍'}</span>
          <span class="suggestion-item__text">${escHtml(s)}</span>
          ${isHist ? `<button class="suggestion-item__del" title="Remove">✕</button>` : ''}`;
        if (isHist) {
          item.querySelector('.suggestion-item__del').onclick = (e) => {
            e.stopPropagation(); removeSearchHistItem(s); showSuggestions();
          };
        }
        item.onclick = (e) => { if (e.target.tagName === 'BUTTON') return; inputEl.value = s; dropdownEl.classList.add('hidden'); onSelect(s); };
        dropdownEl.appendChild(item);
      }
      dropdownEl.classList.remove('hidden');
    }, 200);
  }

  inputEl.addEventListener('focus', showSuggestions);
  inputEl.addEventListener('input', showSuggestions);
  inputEl.addEventListener('keydown', e => {
    if (e.key === 'Escape') { dropdownEl.classList.add('hidden'); inputEl.blur(); }
  });
  document.addEventListener('click', e => {
    if (!dropdownEl.contains(e.target) && e.target !== inputEl) dropdownEl.classList.add('hidden');
  });
}
window.attachSuggestions = attachSuggestions;

// ── Main Menu ──────────────────────────────────────────────────────────────
function openMainMenu(anchorEl) {
  // Remove existing
  document.getElementById('_mainMenu')?.remove();

  const sheet = document.createElement('div'); sheet.id = '_mainMenu'; sheet.className = 'main-menu-sheet';
  const backdrop = document.createElement('div'); backdrop.className = 'main-menu-sheet__backdrop';
  const panel = document.createElement('div'); panel.className = 'main-menu-panel';

  const items = [
    { icon: '🆕', label: 'New Tab', action: () => window.location.href = '/browser' },
    { icon: '🏠', label: 'Home', action: () => window.location.href = '/' },
    { icon: '📜', label: 'History', action: () => window.location.href = '/history' },
    { icon: '🔖', label: 'Bookmarks', action: () => window.location.href = '/bookmarks' },
    { icon: '⬇️', label: 'Downloads', action: () => window.location.href = '/downloads' },
    'sep',
    { icon: '🌐', label: 'Discovery Feed', action: () => { window.location.href = '/'; } },
    { icon: '⚙️', label: 'Settings', action: () => window.location.href = '/settings' },
    { icon: '🔒', label: 'Privacy & Security', action: () => window.location.href = '/settings' },
    { icon: '🧹', label: 'Clear Browsing Data', action: () => { if(confirm('Clear all history and data?')) { clearBrowserHistory(); clearSearchHistory(); showToast('Data cleared'); } } },
    'sep',
    { icon: '🛠', label: 'Admin Panel', action: () => window.location.href = '/admin' },
    { icon: 'ℹ️', label: 'About Pro Browser', action: () => alert('Pro Browser v2.0\nPrivate local search engine + browser\nRunning on Termux / Android') },
  ];

  for (const it of items) {
    if (it === 'sep') {
      const sep = document.createElement('div'); sep.className = 'main-menu-sep'; panel.appendChild(sep); continue;
    }
    const el = document.createElement('div'); el.className = 'main-menu-item';
    el.innerHTML = `<span class="main-menu-item__icon">${it.icon}</span><span>${it.label}</span>`;
    el.onclick = () => { sheet.remove(); it.action(); };
    panel.appendChild(el);
  }

  sheet.appendChild(backdrop); sheet.appendChild(panel);
  document.body.appendChild(sheet);
  backdrop.onclick = () => sheet.remove();
}
window.openMainMenu = openMainMenu;

// ── Discovery Feed ─────────────────────────────────────────────────────────
const FEED_TOPICS = [
  { cat: 'Technology', icon: '💻', items: ['Artificial intelligence', 'Open source software', 'Web development', 'Linux news'] },
  { cat: 'Science', icon: '🔬', items: ['Space exploration', 'Climate research', 'Biology discoveries', 'Physics research'] },
  { cat: 'Design', icon: '🎨', items: ['UI design trends', 'Typography', 'Color theory', 'Minimalist design'] },
  { cat: 'Programming', icon: '⚙️', items: ['Python tips', 'JavaScript frameworks', 'Database optimization', 'API design'] },
  { cat: 'Security', icon: '🔐', items: ['Cybersecurity news', 'Privacy tools', 'Encryption basics', 'Data protection'] },
  { cat: 'Mobile', icon: '📱', items: ['Android development', 'App design', 'Mobile performance', 'PWA'] },
];

function buildFeed() {
  const grid = document.getElementById('feedGrid'); if (!grid) return;
  const mode = getCurrentMode();
  const hist = getSearchHistory().map(it => typeof it==='string'?it:it.q);
  const shuffle = arr => arr.sort(() => Math.random() - .5);
  const cards = [];

  // Personalized from history
  for (const q of hist.slice(0, 2)) {
    cards.push({ cat: 'For You', icon: '⭐', title: q, query: q });
  }

  // Topic suggestions
  const topics = shuffle([...FEED_TOPICS]).slice(0, 4);
  for (const t of topics) {
    const item = shuffle([...t.items])[0];
    cards.push({ cat: t.cat, icon: t.icon, title: item, query: item });
  }

  // Child mode filter
  const filtered = mode === 'child'
    ? cards.filter(c => !['Security','Programming'].includes(c.cat))
    : cards;

  grid.innerHTML = '';
  for (const card of filtered.slice(0, 6)) {
    const el = document.createElement('div'); el.className = 'feed-card';
    el.innerHTML = `
      <div class="feed-card__img-placeholder">${card.icon}</div>
      <div class="feed-card__body">
        <div class="feed-card__cat">${escHtml(card.cat)}</div>
        <div class="feed-card__title">${escHtml(card.title)}</div>
      </div>`;
    el.onclick = () => { addSearchHistory(card.query); window.location.href = `/results?q=${encodeURIComponent(card.query)}`; };
    grid.appendChild(el);
  }
}

// ── Homepage Logic ─────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const isHome = document.querySelector('.home-page');
  if (!isHome) return;

  const input = document.getElementById('searchInput');
  const btn = document.getElementById('searchBtn');
  const dropdown = document.getElementById('suggestDropdown');
  const menuBtn = document.getElementById('menuBtn');
  const modeBadge = document.getElementById('modeBadge');

  // Mode badge
  const mode = getCurrentMode();
  if (modeBadge) {
    const labels = { normal:'Normal', private:'🔒 Private', child:'⭐ Child', developer:'⚙️ Dev' };
    modeBadge.textContent = labels[mode] || 'Normal';
  }

  function doSearch(q) {
    q = (q || input?.value || '').trim(); if (!q) return;
    touchSearchHistory(q);
    addSearchHistory(q);
    window.location.href = `/results?q=${encodeURIComponent(q)}`;
  }

  if (input) {
    input.addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });
    if (dropdown) attachSuggestions(input, dropdown, doSearch);
  }
  if (btn) btn.onclick = () => doSearch();
  if (menuBtn) menuBtn.onclick = () => openMainMenu(menuBtn);

  renderShortcuts();
  renderRecentlyVisited();
  buildFeed();
});

// ── Shortcuts ──────────────────────────────────────────────────────────────
function renderShortcuts() {
  const container = document.getElementById('shortcutsRow'); if (!container) return;
  const shortcuts = getShortcuts(); container.innerHTML = '';
  for (const sc of shortcuts) {
    const domain = (() => { try { return new URL(sc.url).hostname; } catch { return ''; } })();
    const el = document.createElement('div'); el.className = 'shortcut-item';
    el.innerHTML = `
      <div class="shortcut-icon" title="${escHtml(sc.name)}">
        <img src="https://${domain}/favicon.ico" onerror="this.style.display='none';this.nextSibling.style.display=''">
        <span style="display:none">${sc.emoji||'🌐'}</span>
      </div>
      <span class="shortcut-label">${escHtml(sc.name)}</span>`;
    el.querySelector('.shortcut-icon').onclick = () => openInBrowser(sc.url, sc.name);
    el.querySelector('.shortcut-icon').oncontextmenu = (e) => {
      e.preventDefault();
      openCtxMenu([
        { icon:'🌐', label:'Open', action: () => openInBrowser(sc.url, sc.name) },
        { icon:'✏️', label:'Edit', action: () => openEditShortcut(sc) },
        'sep',
        { icon:'🗑️', label:'Remove', action: () => { saveShortcuts(getShortcuts().filter(s=>s.id!==sc.id)); renderShortcuts(); }, danger: true },
      ], e);
    };
    container.appendChild(el);
  }
  // Add btn
  const add = document.createElement('div'); add.className = 'shortcut-item';
  add.innerHTML = `<div class="shortcut-icon shortcut-add" title="Add shortcut" onclick="openAddShortcut()">+</div><span class="shortcut-label">Add</span>`;
  container.appendChild(add);
}

function openAddShortcut() {
  const m = document.getElementById('shortcutModal'); if (!m) return;
  document.getElementById('scName').value = ''; document.getElementById('scUrl').value = '';
  document.getElementById('scEmoji').value = '🌐'; document.getElementById('scModalTitle').textContent = 'Add Shortcut';
  document.getElementById('scEditId').value = ''; m.classList.remove('hidden');
}
function openEditShortcut(sc) {
  const m = document.getElementById('shortcutModal'); if (!m) return;
  document.getElementById('scName').value = sc.name; document.getElementById('scUrl').value = sc.url;
  document.getElementById('scEmoji').value = sc.emoji||'🌐'; document.getElementById('scModalTitle').textContent = 'Edit Shortcut';
  document.getElementById('scEditId').value = sc.id; m.classList.remove('hidden');
}
function closeShortcutModal() { document.getElementById('shortcutModal')?.classList.add('hidden'); }
function saveShortcutModal() {
  const name = document.getElementById('scName').value.trim();
  const url  = document.getElementById('scUrl').value.trim();
  const emoji = document.getElementById('scEmoji').value.trim() || '🌐';
  const editId = document.getElementById('scEditId').value;
  if (!name || !url) { showToast('Name and URL are required'); return; }
  try { new URL(url); } catch { showToast('Invalid URL'); return; }
  const sc = getShortcuts();
  if (editId) { const i = sc.findIndex(s=>s.id===editId); if (i>=0) sc[i]={...sc[i],name,url,emoji}; }
  else sc.push({ id: Date.now().toString(), name, url, emoji });
  saveShortcuts(sc); closeShortcutModal(); renderShortcuts();
}
window.openAddShortcut = openAddShortcut;
window.saveShortcutModal = saveShortcutModal;
window.closeShortcutModal = closeShortcutModal;

// ── Recently Visited ───────────────────────────────────────────────────────
function renderRecentlyVisited() {
  const container = document.getElementById('recentList'); if (!container) return;
  const hist = getBrowserHistory().slice(0, 8);
  const section = document.getElementById('recentSection');
  if (!hist.length) { if(section) section.style.display='none'; return; }
  if(section) section.style.display='';
  container.innerHTML = '';
  for (const h of hist) {
    const domain = (() => { try { return new URL(h.url).hostname; } catch { return ''; } })();
    const el = document.createElement('div'); el.className = 'recent-item';
    el.innerHTML = `
      <img class="recent-item__favicon" src="https://${domain}/favicon.ico" onerror="this.style.display='none'">
      <div style="flex:1;min-width:0">
        <div class="recent-item__title">${escHtml(h.title||h.url)}</div>
        <div class="recent-item__domain">${escHtml(domain)}</div>
      </div>
      <span class="recent-item__time">${formatTime(h.time)}</span>
      <button class="recent-item__del" title="Remove">✕</button>`;
    el.querySelector('.recent-item__del').onclick = e => {
      e.stopPropagation();
      localStorage.setItem(KEYS.BROWSER_HIST, JSON.stringify(getBrowserHistory().filter(x=>x.url!==h.url)));
      renderRecentlyVisited();
    };
    el.onclick = e => { if(e.target.tagName==='BUTTON') return; openInBrowser(h.url, h.title); };
    container.appendChild(el);
  }
}
