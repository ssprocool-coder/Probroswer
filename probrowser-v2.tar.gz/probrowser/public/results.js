'use strict';
/* Pro Browser — Results page */

const params = new URLSearchParams(location.search);
let currentQuery = params.get('q') || '';
let currentPage  = parseInt(params.get('page') || '1');
let currentCat   = params.get('cat') || 'all';

const body = document.getElementById('appBody');

document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('searchInput');
  const btn   = document.getElementById('searchBtn');
  const tabs  = document.getElementById('catTabs');
  const dropdown = document.getElementById('suggestDropdown');
  const menuBtn = document.getElementById('menuBtn');

  if (input) {
    input.value = currentQuery;
    input.addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(input.value); });
    if (dropdown) attachSuggestions(input, dropdown, doSearch);
  }
  if (btn) btn.onclick = () => doSearch(input?.value || '');
  if (menuBtn) menuBtn.onclick = () => openMainMenu(menuBtn);

  if (tabs) {
    tabs.querySelectorAll('.cat-tab').forEach(tab => {
      tab.classList.toggle('active', tab.dataset.cat === currentCat);
      tab.onclick = () => { currentCat = tab.dataset.cat; currentPage = 1; updateUrl(); loadResults(); };
    });
  }

  document.title = currentQuery ? `${currentQuery} — Pro Browser` : 'Pro Browser';
  loadResults();
});

function doSearch(q) {
  q = (q||'').trim(); if (!q) return;
  addSearchHistory(q);
  currentQuery = q; currentPage = 1;
  updateUrl(); loadResults();
}

function updateUrl() {
  const p = new URLSearchParams({ q: currentQuery, page: currentPage, cat: currentCat });
  history.replaceState({}, '', `/results?${p}`);
  document.title = `${currentQuery} — Pro Browser`;
  document.querySelectorAll('.cat-tab').forEach(t => t.classList.toggle('active', t.dataset.cat === currentCat));
  const inp = document.getElementById('searchInput'); if (inp) inp.value = currentQuery;
}

async function loadResults() {
  body.innerHTML = '<div class="loading-wrap"><div class="spinner"></div></div>';
  if (currentCat === 'maps') { renderMaps(); return; }
  if (currentCat === 'images') { await loadImages(); return; }
  if (currentCat === 'videos') { await loadVideos(); return; }
  try {
    const r = await fetch(`/api/search?q=${encodeURIComponent(currentQuery)}&page=${currentPage}`);
    const data = await r.json();
    if (currentCat === 'news') renderNews(data);
    else renderAll(data);
  } catch (err) {
    body.innerHTML = `<div class="empty-state"><div class="empty-state__icon">⚠️</div><div class="empty-state__title">Error</div><div class="empty-state__msg">${escHtml(err.message)}</div></div>`;
  }
}

async function renderAll(data) {
  const html = [];
  html.push(`<div class="result-meta">About <span class="result-count">${data.total||0}</span> results ${data.searchTime ? `(${data.searchTime})` : ''}</div>`);
  html.push(`<div class="results-list">`);

  if (!data.total) {
    html.push(`<div class="empty-state"><div class="empty-state__icon">🔍</div><div class="empty-state__title">No results found</div><div class="empty-state__msg">Try crawling more websites in <a href="/admin">Admin</a></div></div>`);
    html.push('</div>'); body.innerHTML = html.join(''); return;
  }

  html.push(`<div id="aiOverviewArea"></div>`);

  for (const r of data.results || []) {
    const domain = r.domain || '';
    const url = escHtml(r.url);
    const title = escHtml(r.title);
    html.push(`
      <div class="result-card" onclick="openResult('${url}','${title}')">
        <img class="result-card__favicon" src="https://${escHtml(domain)}/favicon.ico" onerror="this.style.display='none'">
        <div class="result-card__body">
          <div class="result-card__domain">🌐 ${escHtml(domain)}</div>
          <div class="result-card__title">${title}</div>
          <div class="result-card__url">${url}</div>
          <div class="result-card__snippet">${escHtml(r.snippet||'')}</div>
        </div>
        <button class="result-card__menu-btn" onclick="event.stopPropagation();resultMenu(event,'${url}','${title}')">⋮</button>
      </div>`);
  }

  // Pagination
  if (data.totalPages > 1) {
    html.push('<div class="pagination">');
    if (currentPage > 1) html.push(`<button class="pagination__btn" onclick="goPage(${currentPage-1})">← Prev</button>`);
    const start = Math.max(1, currentPage-2), end = Math.min(data.totalPages, currentPage+2);
    for (let i = start; i <= end; i++)
      html.push(`<button class="pagination__btn${i===currentPage?' active':''}" onclick="goPage(${i})">${i}</button>`);
    if (currentPage < data.totalPages) html.push(`<button class="pagination__btn" onclick="goPage(${currentPage+1})">Next →</button>`);
    html.push('</div>');
  }

  html.push('</div>');
  body.innerHTML = html.join('');
  loadAIOverview();
}

async function loadAIOverview() {
  const area = document.getElementById('aiOverviewArea');
  if (!area || !currentQuery) return;
  try {
    const r = await fetch(`/api/ai/overview?q=${encodeURIComponent(currentQuery)}`);
    const data = await r.json();
    if (data.unavailable) return;
    const sources = (data.sources||[]).map(s =>
      `<a class="ai-source-chip" href="#" onclick="openResult('${escHtml(s.url)}','${escHtml(s.title)}');return false">${escHtml(s.domain||s.title)}</a>`
    ).join('');
    area.innerHTML = `
      <div class="ai-overview">
        <div class="ai-overview__header">✦ AI Overview</div>
        <div class="ai-overview__text">${escHtml(data.text)}</div>
        ${sources ? `<div class="ai-overview__sources">Sources: ${sources}</div>` : ''}
      </div>`;
  } catch {}
}

async function loadImages() {
  try {
    const r = await fetch(`/api/search/images?q=${encodeURIComponent(currentQuery)}`);
    const data = await r.json();
    if (!data.results?.length) {
      body.innerHTML = `<div class="empty-state" style="padding:40px"><div class="empty-state__icon">🖼️</div><div class="empty-state__title">No images indexed</div><div class="empty-state__msg">Crawl websites to discover images.</div></div>`;
      return;
    }
    let html = `<div class="result-meta">Found <span class="result-count">${data.total}</span> images</div><div class="images-grid">`;
    for (const img of data.results) {
      // BUG FIX: each image keeps its own source_url, img url, alt, domain
      const imgUrl = escHtml(img.url || '');
      const srcUrl = escHtml(img.source_url || img.page_url || img.url || '');
      const altText = escHtml(img.alt || img.title || img.domain || '');
      const domain = escHtml(img.domain || '');
      html += `
        <div class="image-card" data-src="${srcUrl}" data-img="${imgUrl}" data-alt="${altText}" title="${altText}">
          <img src="${imgUrl}" alt="${altText}" loading="lazy" onerror="this.parentNode.innerHTML='<div class=&quot;image-card__broken&quot;>🖼️</div>'">
          <div class="image-card__overlay">
            <div class="image-card__alt">${altText}</div>
            <div class="image-card__domain">${domain}</div>
          </div>
        </div>`;
    }
    html += '</div>';
    body.innerHTML = html;
    // Attach individual click handlers (fixes same-URL bug)
    body.querySelectorAll('.image-card[data-src]').forEach(card => {
      card.onclick = () => {
        const src = card.dataset.src;
        const alt = card.dataset.alt;
        if (src) openResult(src, alt || src);
      };
    });
  } catch (err) {
    body.innerHTML = `<div class="empty-state"><div class="empty-state__icon">⚠️</div><div class="empty-state__msg">${escHtml(err.message)}</div></div>`;
  }
}

async function loadVideos() {
  try {
    const r = await fetch(`/api/search/videos?q=${encodeURIComponent(currentQuery)}`);
    const data = await r.json();
    if (!data.results?.length) {
      body.innerHTML = `<div class="empty-state" style="padding:40px"><div class="empty-state__icon">▶️</div><div class="empty-state__title">No videos indexed</div><div class="empty-state__msg">Crawl websites with video embeds to discover videos.</div></div>`;
      return;
    }
    let html = `<div class="result-meta">Found <span class="result-count">${data.total}</span> videos</div><div class="videos-grid">`;
    for (const vid of data.results) {
      const vidUrl = escHtml(vid.url||'');
      const vidTitle = escHtml(vid.title||vid.url||'');
      const thumb = vid.thumbnail ? escHtml(vid.thumbnail) : '';
      html += `
        <div class="video-card" data-url="${vidUrl}" data-title="${vidTitle}">
          <div class="video-card__thumb">
            ${thumb ? `<img src="${thumb}" alt="" onerror="this.style.display='none'">` : ''}
            <div class="video-card__play">▶</div>
          </div>
          <div class="video-card__info">
            <div class="video-card__title">${vidTitle}</div>
            <div class="video-card__domain">🌐 ${escHtml(vid.domain||'')}</div>
          </div>
        </div>`;
    }
    html += '</div>';
    body.innerHTML = html;
    body.querySelectorAll('.video-card[data-url]').forEach(card => {
      card.onclick = () => openResult(card.dataset.url, card.dataset.title);
    });
  } catch (err) {
    body.innerHTML = `<div class="empty-state"><div class="empty-state__icon">⚠️</div><div class="empty-state__msg">${escHtml(err.message)}</div></div>`;
  }
}

function renderNews(data) {
  if (!data.total) {
    body.innerHTML = `<div class="empty-state" style="padding:40px"><div class="empty-state__icon">📰</div><div class="empty-state__title">No news results</div></div>`;
    return;
  }
  const newsResults = (data.results||[]).filter(r => r.snippet && r.title && r.title !== r.url);
  let html = `<div class="result-meta">About <span class="result-count">${newsResults.length}</span> articles</div><div class="news-list">`;
  for (const r of newsResults) {
    html += `
      <div class="news-card" data-url="${escHtml(r.url)}" data-title="${escHtml(r.title)}">
        <div class="news-card__source">🌐 ${escHtml(r.domain)}</div>
        <div class="news-card__title">${escHtml(r.title)}</div>
        <div class="news-card__snippet">${escHtml(r.snippet||'')}</div>
      </div>`;
  }
  html += '</div>';
  body.innerHTML = html;
  body.querySelectorAll('.news-card[data-url]').forEach(card => {
    card.onclick = () => openResult(card.dataset.url, card.dataset.title);
  });
}

function renderMaps() {
  body.innerHTML = `
    <div class="maps-placeholder">
      <div class="maps-placeholder__icon">🗺️</div>
      <div class="maps-placeholder__title">Maps</div>
      <div class="maps-placeholder__msg">Search for: <strong>"${escHtml(currentQuery)}"</strong></div>
      <button class="maps-open-btn" onclick="openMaps()">Open Maps</button>
      <div style="margin-top:10px;font-size:.78rem;color:var(--text-muted)">Opens your installed maps app</div>
    </div>`;
}

window.openMaps = function() {
  window.location.href = `geo:0,0?q=${encodeURIComponent(currentQuery)}`;
  setTimeout(() => window.open(`https://maps.google.com/?q=${encodeURIComponent(currentQuery)}`, '_blank'), 800);
};

function openResult(url, title) {
  addBrowserHistory(title||url, url);
  const p = new URLSearchParams({ url, title: title||'' });
  window.location.href = `/browser?${p}`;
}
window.openResult = openResult;

function resultMenu(e, url, title) {
  e.stopPropagation();
  openCtxMenu([
    { icon:'🌐', label:'Open', action: () => openResult(url, title) },
    { icon:'➕', label:'New Tab', action: () => { const p = new URLSearchParams({url,title,newtab:'1'}); window.open(`/browser?${p}`, '_blank'); } },
    { icon:'📋', label:'Copy Link', action: () => { navigator.clipboard.writeText(url).catch(()=>{}); showToast('Copied!'); } },
    { icon:'🔖', label:'Bookmark', action: () => addBookmark(url, title) },
    'sep',
    { icon:'🔗', label:'Open Externally', action: () => window.open(url, '_blank') },
  ], e);
}
window.resultMenu = resultMenu;

function goPage(p) { currentPage = p; updateUrl(); loadResults(); window.scrollTo(0,0); }
window.goPage = goPage;
